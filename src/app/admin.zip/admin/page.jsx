export default function AdminHome() {
  return (
    <div>
      <h2>Chào mừng đến với trang quản trị GTN Shop</h2>
      <p>Vui lòng chọn chức năng ở menu bên trái để quản lý hệ thống.</p>
    </div>
  );
}
