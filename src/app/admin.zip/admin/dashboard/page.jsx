"use client";
import "./../../admin/admin.scss";

export default function DashboardPage() {
  return (
    <div className="admin-page">
      <h2>📊 Trang tổng quan</h2>

      <div className="dashboard-stats">
        <div className="stat-card">
          <h3>Doanh thu hôm nay</h3>
          <p>5.000.000 ₫</p>
        </div>
        <div className="stat-card">
          <h3>Đơn hàng mới</h3>
          <p>12</p>
        </div>
        <div className="stat-card">
          <h3>Khách hàng mới</h3>
          <p>4</p>
        </div>
      </div>

      <div className="dashboard-chart">
        <h3>Thống kê doanh thu theo ngày</h3>
        <div className="chart-placeholder">
          (Biểu đồ sẽ hiển thị ở đây)
        </div>
      </div>
    </div>
  );
}
