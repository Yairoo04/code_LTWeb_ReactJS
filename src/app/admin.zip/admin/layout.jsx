"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import "./admin.scss";

export default function AdminLayout({ children }) {
  const path = usePathname();

  return (
    <div className="admin-container">
      <aside className="admin-sidebar">
        <h2>GTN Admin</h2>
        <nav>
          <ul>
            <li className={path === "/admin/dashboard" ? "active" : ""}>
              <Link href="/admin/dashboard">🏠 Dashboard</Link>
            </li>
            <li className={path === "/admin/products" ? "active" : ""}>
              <Link href="/admin/products">📦 Sản phẩm</Link>
            </li>
            <li className={path === "/admin/categories" ? "active" : ""}>
              <Link href="/admin/categories">📂 Danh mục</Link>
            </li>
            <li className={path === "/admin/orders" ? "active" : ""}>
              <Link href="/admin/orders">🧾 Đơn hàng</Link>
            </li>
            <li className={path === "/admin/customers" ? "active" : ""}>
              <Link href="/admin/customers">👤 Khách hàng</Link>
            </li>
            <li className={path === "/admin/accounts" ? "active" : ""}>
              <Link href="/admin/accounts">🔐 Tài khoản</Link>
            </li>
            <li className={path === "/admin/statistics" ? "active" : ""}>
              <Link href="/admin/statistics">📊 Thống kê</Link>
            </li>
          </ul>
        </nav>
      </aside>

      <main className="admin-content">
        <header className="admin-header">
          <span>Xin chào, Admin</span>
          <button className="logout-btn">Đăng xuất</button>
        </header>
        <section className="admin-main">{children}</section>
      </main>
    </div>
  );
}
